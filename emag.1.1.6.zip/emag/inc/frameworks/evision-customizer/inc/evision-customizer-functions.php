<?php
require_once trailingslashit( EVISION_CUSTOMIZER_PATH ) . 'inc/functions/get-all-values.php';
require_once trailingslashit( EVISION_CUSTOMIZER_PATH ) . 'inc/functions/get-repeated-all-value.php';
require_once trailingslashit( EVISION_CUSTOMIZER_PATH ) . 'inc/functions/get-single-value.php';